const Header = () => {
    return (
        <header>
            <h2>Modul Reactjs dasar</h2>
            <nav>
                <a href="">Beranda</a> | <a href="">Tentang</a>
            </nav>
        </header>

    )
}
export default Header